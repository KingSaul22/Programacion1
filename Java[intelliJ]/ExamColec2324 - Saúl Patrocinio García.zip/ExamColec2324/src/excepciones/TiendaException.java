package excepciones;

public class TiendaException extends Exception {
    public TiendaException(String message) {
        super(message);
    }
}