package Exceptions;

public class NioException extends Exception {
    public NioException(String message) {
        super(message);
    }
}
