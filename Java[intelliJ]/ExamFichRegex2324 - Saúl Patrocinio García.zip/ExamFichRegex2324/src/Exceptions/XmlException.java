package Exceptions;

public class XmlException extends Exception {
    public XmlException(String message) {
        super(message);
    }
}
