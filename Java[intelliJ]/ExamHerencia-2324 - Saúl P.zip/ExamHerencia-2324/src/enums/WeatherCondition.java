package enums;

public enum WeatherCondition {
    LLUVIA, SOLEADO, TORMENTA_ELECTRICA, TORMENTA_ARENA
}
