package exceptions;

public class MuerteException extends Exception{
    public MuerteException(String message) {
        super(message);
    }
}
