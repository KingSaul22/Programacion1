package exceptions;

public class RoundStartException extends Exception{
    public RoundStartException(String message) {
        super(message);
    }
}
