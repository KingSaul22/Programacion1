package enums;

public enum TColor {
    BLANCO, NEGRO, AMARILLO
}
