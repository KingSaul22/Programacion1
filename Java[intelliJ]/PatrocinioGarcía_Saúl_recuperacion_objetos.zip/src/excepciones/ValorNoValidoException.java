package excepciones;

public class ValorNoValidoException extends Exception {
    public ValorNoValidoException(String message) {
        super(message);
    }
}
