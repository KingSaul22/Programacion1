public class Dispositivo {
    private String nombre, conexion, protocolo;

    public Dispositivo(java.lang.String nombre, java.lang.String conexion, java.lang.String protocolo) {
        this.nombre = nombre;
        this.conexion = conexion;
        this.protocolo = protocolo;
    }
}
